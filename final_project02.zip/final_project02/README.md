# Switchboard 02

Secure credential manager built with Yew.

## Structure

- `src/frontend/` - UI components and pages
- `src/backend/` - API client, auth, and models
- `src/app.rs` - Main app router

## Dev

```bash
trunk serve --port 1422
```

## Build

```bash
trunk build --release
```
