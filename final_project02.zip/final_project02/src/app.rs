use crate::frontend::components::Header;
use crate::frontend::pages::add_credential::AddCredential;
use crate::frontend::pages::list_services::{ListServices, Route};
use crate::frontend::pages::view_credential::ViewCredential;
use yew::prelude::*;
use yew_router::prelude::*;

#[function_component(App)]
pub fn app() -> Html {
    html! {
        <BrowserRouter>
            <div class="app">
                <Header />
                <div class="container">
                    <Switch<Route> render={switch} />
                </div>
            </div>
        </BrowserRouter>
    }
}

fn switch(routes: Route) -> Html {
    match routes {
        Route::List => html! { <ListServices /> },
        Route::ViewCredential { service } => html! { <ViewCredential {service} /> },
        Route::AddCredential => html! { <AddCredential /> },
    }
}
