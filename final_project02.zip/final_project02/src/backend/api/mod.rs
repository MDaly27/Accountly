use crate::backend::auth::load_session;
use crate::backend::models::{AddCredentialRequest, ListResp, OneCredResp, PostResp};
use gloo_net::http::{Request, RequestBuilder};

const API_BASE: &str = "https://gspfonqp30.execute-api.us-east-2.amazonaws.com";

fn with_auth_header(mut req: RequestBuilder) -> RequestBuilder {
    if let Some(session) = load_session() {
        if !session.is_demo {
            if let Some(key) = session.api_key {
                req = req.header("x-api-key", &key);
            }
        }
    }
    req
}

pub async fn list_services(username: &str) -> Result<ListResp, String> {
    let url = format!("{}/creds?username={}", API_BASE, username);

    let response = with_auth_header(Request::get(&url))
        .send()
        .await
        .map_err(|e| format!("Request failed: {}", e))?;

    if !response.ok() {
        return Err(format!("API error: {}", response.status()));
    }

    response
        .json::<ListResp>()
        .await
        .map_err(|e| format!("Failed to parse response: {}", e))
}

pub async fn get_credential(username: &str, service: &str) -> Result<OneCredResp, String> {
    let url = format!("{}/creds/{}?username={}", API_BASE, service, username);

    let response = with_auth_header(Request::get(&url))
        .send()
        .await
        .map_err(|e| format!("Request failed: {}", e))?;

    if !response.ok() {
        return Err(format!("API error: {}", response.status()));
    }

    response
        .json::<OneCredResp>()
        .await
        .map_err(|e| format!("Failed to parse response: {}", e))
}

pub async fn add_credential(
    username: &str,
    service: &str,
    password: &str,
) -> Result<PostResp, String> {
    let url = format!("{}/creds", API_BASE);
    let body = AddCredentialRequest {
        username: username.to_string(),
        service: service.to_string(),
        password: password.to_string(),
    };

    let response = with_auth_header(Request::post(&url))
        .json(&body)
        .map_err(|e| format!("Failed to serialize request: {}", e))?
        .send()
        .await
        .map_err(|e| format!("Request failed: {}", e))?;

    if !response.ok() {
        return Err(format!("API error: {}", response.status()));
    }

    response
        .json::<PostResp>()
        .await
        .map_err(|e| format!("Failed to parse response: {}", e))
}
