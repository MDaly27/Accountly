use gloo_storage::{LocalStorage, Storage};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

const SESSION_KEY: &str = "accountly_session";

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct UserSession {
    pub email: String,
    pub api_key: Option<String>,
    pub is_demo: bool,
}

pub fn load_session() -> Option<UserSession> {
    LocalStorage::get::<UserSession>(SESSION_KEY).ok()
}

pub fn save_session(session: &UserSession) {
    let _ = LocalStorage::set(SESSION_KEY, session);
}

pub fn clear_session() {
    let _ = LocalStorage::delete(SESSION_KEY);
}

pub fn generate_api_key() -> String {
    Uuid::new_v4().to_string()
}

pub fn create_demo_session(email_hint: Option<String>) -> UserSession {
    UserSession {
        email: email_hint.unwrap_or_else(|| "demo@example.com".to_string()),
        api_key: None,
        is_demo: true,
    }
}
