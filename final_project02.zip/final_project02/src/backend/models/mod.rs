use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct ServiceInfo {
    pub username: Option<String>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub category: Option<String>,
    #[serde(default)]
    pub last_used: Option<String>,
    #[serde(default)]
    pub created_at: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct ListResp {
    pub username: String,
    pub services: HashMap<String, ServiceInfo>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct OneCredResp {
    pub username: String,
    pub service: String,
    pub password: String,
    #[serde(default)]
    pub two_fa_enabled: bool,
    #[serde(default)]
    pub two_fa_method: Option<String>,
    #[serde(default)]
    pub phone_number: Option<String>,
    #[serde(default)]
    pub email: Option<String>,
    #[serde(default)]
    pub backup_email: Option<String>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub category: Option<String>,
    #[serde(default)]
    pub notes: Option<String>,
    #[serde(default)]
    pub last_used: Option<String>,
    #[serde(default)]
    pub created_at: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct PostResp {
    pub ok: bool,
    pub username: String,
    pub service: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AddCredentialRequest {
    pub username: String,
    pub service: String,
    pub password: String,
}
