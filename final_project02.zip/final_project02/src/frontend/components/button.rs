use yew::prelude::*;

#[derive(Properties, PartialEq)]
pub struct ButtonProps {
    pub label: String,
    pub onclick: Callback<MouseEvent>,
    #[prop_or(false)]
    pub loading: bool,
    #[prop_or_default]
    pub variant: ButtonVariant,
}

#[derive(Default, PartialEq, Clone)]
pub enum ButtonVariant {
    #[default]
    Primary,
    Secondary,
}

#[function_component(StyledButton)]
pub fn styled_button(props: &ButtonProps) -> Html {
    let class = match props.variant {
        ButtonVariant::Primary => "btn btn-primary",
        ButtonVariant::Secondary => "btn btn-secondary",
    };

    html! {
        <button
            class={class}
            onclick={props.onclick.clone()}
            disabled={props.loading}
        >
            if props.loading {
                <span class="loading-spinner"></span>
            }
            <span>{ &props.label }</span>
        </button>
    }
}
