use yew::prelude::*;

// Card Component
#[derive(Properties, PartialEq)]
pub struct CardProps {
    pub children: Html,
    #[prop_or_default]
    pub onclick: Option<Callback<MouseEvent>>,
    #[prop_or(false)]
    pub clickable: bool,
}

#[function_component(Card)]
pub fn card(props: &CardProps) -> Html {
    let class = if props.clickable { "card card-clickable" } else { "card" };
    html! {
        <div {class} onclick={props.onclick.clone()}>
            { props.children.clone() }
        </div>
    }
}

// Header Component
#[function_component(Header)]
pub fn header() -> Html {
    let session = crate::backend::auth::load_session();
    let has_session = session.is_some();

    let on_logout = Callback::from(move |_| {
        crate::backend::auth::clear_session();
        if let Some(window) = web_sys::window() {
            let _ = window.location().reload();
        }
    });

    html! {
        <div class="header">
            <div class="header-content">
                <div>
<h1>{"Switchboard 02"}</h1>
                    <p class="subtitle">{"Secure Credential Manager"}</p>
                </div>
                if has_session {
                    <div class="header-user">
                        if let Some(s) = session {
                            <div class="user-info">
                                <span class="user-badge">{ if s.is_demo { "🎭 Demo Mode" } else { "👤" } }</span>
                                <span class="user-email">{ s.email }</span>
                            </div>
                        }
                        <button class="btn btn-logout" onclick={on_logout}>{"Logout"}</button>
                    </div>
                }
            </div>
        </div>
    }
}

// Loading Spinner
#[function_component(LoadingSpinner)]
pub fn loading_spinner() -> Html {
    html! { <div class="spinner-container"><div class="spinner"></div></div> }
}

// Toast Notification
#[derive(Properties, PartialEq)]
pub struct ToastProps {
    pub message: Option<String>,
    #[prop_or_default]
    pub variant: ToastVariant,
}

#[derive(Default, PartialEq, Clone)]
pub enum ToastVariant {
    Success,
    Error,
    #[default]
    Info,
}

#[function_component(Toast)]
pub fn toast(props: &ToastProps) -> Html {
    if let Some(msg) = &props.message {
        let class = match props.variant {
            ToastVariant::Success => "toast toast-success",
            ToastVariant::Error => "toast toast-error",
            ToastVariant::Info => "toast toast-info",
        };
        html! { <div {class}><span>{ msg }</span></div> }
    } else {
        html! {}
    }
}
