use web_sys::HtmlInputElement;
use yew::prelude::*;

#[derive(Properties, PartialEq)]
pub struct InputProps {
    pub placeholder: String,
    pub value: String,
    pub on_input: Callback<String>,
    #[prop_or_default]
    pub input_type: Option<String>,
}

#[function_component(StyledInput)]
pub fn styled_input(props: &InputProps) -> Html {
    let input_type = props
        .input_type
        .clone()
        .unwrap_or_else(|| "text".to_string());

    let oninput = {
        let on_input = props.on_input.clone();
        Callback::from(move |e: InputEvent| {
            let input: HtmlInputElement = e.target_unchecked_into();
            on_input.emit(input.value());
        })
    };

    html! {
        <input
            type={input_type}
            class="styled-input"
            placeholder={props.placeholder.clone()}
            value={props.value.clone()}
            {oninput}
        />
    }
}
