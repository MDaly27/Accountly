use yew::prelude::*;

#[derive(Properties, PartialEq)]
pub struct ServiceIconProps {
    pub service: String,
}

#[function_component(ServiceIcon)]
pub fn service_icon(props: &ServiceIconProps) -> Html {
    let name = props.service.to_lowercase();
    let url = format!("https://cdn.simpleicons.org/{}/10b981", name);

    html! {
        <div style="width:28px;height:28px;border-radius:6px;background:#0f172a;display:flex;align-items:center;justify-content:center;border:1px solid #262626;overflow:hidden">
            <img src={url} alt={name.clone()} style="width:20px;height:20px" onerror={Callback::from(move |_| ())} />
        </div>
    }
}
