use crate::backend::api;
use crate::frontend::components::*;
use crate::frontend::pages::list_services::Route;
use wasm_bindgen_futures::spawn_local;
use yew::prelude::*;
use yew_router::prelude::*;

#[function_component(AddCredential)]
pub fn add_credential() -> Html {
    let username = use_state(String::new);
    let service = use_state(String::new);
    let password = use_state(String::new);
    let phone = use_state(String::new);
    let email = use_state(String::new);
    let backup_email = use_state(String::new);
    let loading = use_state(|| false);
    let error = use_state(|| None::<String>);
    let success = use_state(|| false);
    let navigator = use_navigator().unwrap();

    let on_username_input = {
        let username = username.clone();
        Callback::from(move |value: String| { username.set(value); })
    };

    let on_service_input = {
        let service = service.clone();
        Callback::from(move |value: String| { service.set(value); })
    };

    let on_password_input = {
        let password = password.clone();
        Callback::from(move |value: String| { password.set(value); })
    };

    let on_phone_input = {
        let phone = phone.clone();
        Callback::from(move |value: String| { phone.set(value); })
    };

    let on_email_used_input = {
        let email = email.clone();
        Callback::from(move |value: String| { email.set(value); })
    };

    let on_backup_email_input = {
        let backup_email = backup_email.clone();
        Callback::from(move |value: String| { backup_email.set(value); })
    };

    let on_submit = {
        let username = username.clone();
        let service = service.clone();
        let password = password.clone();
        let loading = loading.clone();
        let error = error.clone();
        let success = success.clone();
        let navigator = navigator.clone();

        Callback::from(move |_: MouseEvent| {
            let username_val = (*username).clone();
            let service_val = (*service).clone();
            let password_val = (*password).clone();

            if username_val.is_empty() || service_val.is_empty() || password_val.is_empty() {
                error.set(Some("All required fields must be filled".to_string()));
                return;
            }

            let loading = loading.clone();
            let error = error.clone();
            let success = success.clone();
            let username = username.clone();
            let service = service.clone();
            let password = password.clone();
            let navigator = navigator.clone();

            loading.set(true);
            error.set(None);

            // Note: phone/email fields are optional UI metadata and not sent to the current API.
            spawn_local(async move {
                match api::add_credential(&username_val, &service_val, &password_val).await {
                    Ok(_) => {
                        success.set(true);
                        error.set(None);
                        username.set(String::new());
                        service.set(String::new());
                        password.set(String::new());

                        gloo::timers::future::TimeoutFuture::new(1_000).await;
                        navigator.push(&Route::List);
                    }
                    Err(e) => {
                        error.set(Some(format!("Failed to add credential: {}", e)));
                        success.set(false);
                    }
                }
                loading.set(false);
            });
        })
    };

    let on_back = { Callback::from(move |_| { navigator.push(&Route::List); }) };

    html! {
        <div class="page">
            <div class="page-header">
                <h2>{"Add New Credential"}</h2>
                <p class="page-subtitle">{"Store a new password securely"}</p>
            </div>

            <div class="example-data">
                <h4>{"Example:"}</h4>
                <ul>
                    <li>{"Username: john_doe"}</li>
                    <li>{"Service: github"}</li>
                    <li>{"Password: YourSecurePassword123!"}</li>
                    <li>{"Phone: +1 (555) 123-4567 (optional)"}</li>
                    <li>{"Email Used: john@example.com (optional)"}</li>
                    <li>{"Backup Email: john.backup@example.com (optional)"}</li>
                </ul>
            </div>

            <Card>
                <div class="form">
                    <div class="form-group">
                        <label>{"Username"}</label>
                        <StyledInput placeholder="e.g., john_doe" value={(*username).clone()} on_input={on_username_input} />
                    </div>

                    <div class="form-group">
                        <label>{"Service Name"}</label>
                        <StyledInput placeholder="e.g., github, gmail, aws" value={(*service).clone()} on_input={on_service_input} />
                    </div>

                    <div class="form-group">
                        <label>{"Password"}</label>
                        <StyledInput placeholder="Enter your password" value={(*password).clone()} on_input={on_password_input} input_type={Some("password".to_string())} />
                    </div>

                    <div class="form-group">
                        <label>{"Phone Number (optional)"}</label>
                        <StyledInput placeholder="e.g., +1 (555) 123-4567" value={(*phone).clone()} on_input={on_phone_input} />
                    </div>

                    <div class="form-group">
                        <label>{"Email Used (optional)"}</label>
                        <StyledInput placeholder="e.g., john@example.com" value={(*email).clone()} on_input={on_email_used_input} />
                    </div>

                    <div class="form-group">
                        <label>{"Backup Email (optional)"}</label>
                        <StyledInput placeholder="e.g., john.backup@example.com" value={(*backup_email).clone()} on_input={on_backup_email_input} />
                    </div>

                    <div class="form-actions">
                        <StyledButton label="Add Credential" onclick={on_submit} loading={*loading} variant={ButtonVariant::Primary} />
                        <StyledButton label="Cancel" onclick={on_back} variant={ButtonVariant::Secondary} />
                    </div>
                </div>
            </Card>

            <Toast message={(*error).clone()} variant={ToastVariant::Error} />
            if *success { <Toast message={Some("Credential added successfully!".to_string())} variant={ToastVariant::Success} /> }
        </div>
    }
}
