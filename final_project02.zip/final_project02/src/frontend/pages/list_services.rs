use crate::backend::api;
use crate::backend::auth::{create_demo_session, generate_api_key, load_session, save_session, UserSession};
use crate::backend::models::ServiceInfo;
use crate::frontend::components::*;
use gloo_storage::{LocalStorage, Storage};
use wasm_bindgen_futures::spawn_local;
use yew::prelude::*;
use yew_router::prelude::*;

const STORAGE_KEY: &str = "accountly_services";

#[derive(Clone, Routable, PartialEq)]
pub enum Route {
    #[at("/")]
    List,
    #[at("/view/:service")]
    ViewCredential { service: String },
    #[at("/add")]
    AddCredential,
}

fn get_example_services() -> Vec<(String, ServiceInfo)> {
    vec![
        ("github".to_string(), ServiceInfo { 
            username: Some("demo".to_string()),
            tags: vec!["work".to_string(), "dev".to_string()],
            category: Some("Development".to_string()),
            last_used: Some("2 days ago".to_string()),
            created_at: Some("2024-01-15".to_string()),
        }),
        ("gmail".to_string(), ServiceInfo { 
            username: Some("demo@example.com".to_string()),
            tags: vec!["personal".to_string(), "email".to_string()],
            category: Some("Email".to_string()),
            last_used: Some("1 hour ago".to_string()),
            created_at: Some("2023-11-20".to_string()),
        }),
        ("aws".to_string(), ServiceInfo { 
            username: Some("demo-admin".to_string()),
            tags: vec!["work".to_string(), "cloud".to_string(), "critical".to_string()],
            category: Some("Infrastructure".to_string()),
            last_used: Some("5 hours ago".to_string()),
            created_at: Some("2024-02-01".to_string()),
        }),
        ("linkedin".to_string(), ServiceInfo { 
            username: Some("demo".to_string()),
            tags: vec!["professional".to_string(), "social".to_string()],
            category: Some("Social Media".to_string()),
            last_used: Some("1 week ago".to_string()),
            created_at: Some("2023-08-10".to_string()),
        }),
        ("slack".to_string(), ServiceInfo { 
            username: Some("demo".to_string()),
            tags: vec!["work".to_string(), "communication".to_string()],
            category: Some("Communication".to_string()),
            last_used: Some("30 mins ago".to_string()),
            created_at: Some("2024-01-05".to_string()),
        }),
        ("digitalocean".to_string(), ServiceInfo { 
            username: Some("demo".to_string()),
            tags: vec!["work".to_string(), "cloud".to_string(), "servers".to_string()],
            category: Some("Infrastructure".to_string()),
            last_used: Some("3 days ago".to_string()),
            created_at: Some("2024-03-12".to_string()),
        }),
        ("stripe".to_string(), ServiceInfo { 
            username: Some("demo@business.com".to_string()),
            tags: vec!["financial".to_string(), "business".to_string()],
            category: Some("Finance".to_string()),
            last_used: Some("1 day ago".to_string()),
            created_at: Some("2024-02-20".to_string()),
        }),
        ("notion".to_string(), ServiceInfo { 
            username: Some("demo".to_string()),
            tags: vec!["productivity".to_string(), "notes".to_string()],
            category: Some("Productivity".to_string()),
            last_used: Some("2 hours ago".to_string()),
            created_at: Some("2023-12-01".to_string()),
        }),
    ]
}

#[function_component(ListServices)]
pub fn list_services() -> Html {
    let session = use_state::<Option<UserSession>, _>(load_session);
    let email_input = use_state(String::new);
    let services = use_state(Vec::<(String, ServiceInfo)>::new);
    let loading = use_state(|| false);
    let error = use_state(|| None::<String>);
    let navigator = use_navigator().unwrap();

    // Load from local storage on mount
    use_effect_with((), {
        let services = services.clone();
        move |_| {
            if let Ok(stored_services) = LocalStorage::get::<Vec<(String, ServiceInfo)>>(STORAGE_KEY) {
                services.set(stored_services);
            }
            || ()
        }
    });

    // Auto-load example data in demo mode
    use_effect_with(session.clone(), {
        let services = services.clone();
        move |sess| {
            if let Some(s) = &**sess {
                if s.is_demo {
                    let example_services = get_example_services();
                    let _ = LocalStorage::set(STORAGE_KEY, &example_services);
                    services.set(example_services);
                }
            }
            || ()
        }
    });

    let on_demo = {
        let session = session.clone();
        let email_input = email_input.clone();
        let services = services.clone();
        Callback::from(move |_| {
            let s = create_demo_session(if email_input.is_empty() { None } else { Some((*email_input).clone()) });
            save_session(&s);
            session.set(Some(s));
            let example_services = get_example_services();
            let _ = LocalStorage::set(STORAGE_KEY, &example_services);
            services.set(example_services);
        })
    };

    let on_signup = {
        let session = session.clone();
        let email_input = email_input.clone();
        let error = error.clone();
        Callback::from(move |_| {
            let email = (*email_input).trim().to_string();
            if email.is_empty() {
                error.set(Some("Please enter your email".to_string()));
                return;
            }
            let key = generate_api_key();
            let s = UserSession { email, api_key: Some(key), is_demo: false };
            save_session(&s);
            session.set(Some(s));
            error.set(None);
        })
    };

    let on_email_input = {
        let email_input = email_input.clone();
        Callback::from(move |value: String| email_input.set(value))
    };

    let on_load_services = {
        let session = session.clone();
        let services = services.clone();
        let loading = loading.clone();
        let error = error.clone();
        Callback::from(move |_: MouseEvent| {
            let maybe_session = (*session).clone();
            if maybe_session.is_none() {
                error.set(Some("Please sign up or select Demo mode".to_string()));
                return;
            }
            let s = maybe_session.unwrap();
            if s.is_demo {
                // Demo already loaded
                return;
            }
            let services = services.clone();
            let loading = loading.clone();
            let error = error.clone();
            let username_val = s.email.clone();
            loading.set(true);
            error.set(None);
            spawn_local(async move {
                match api::list_services(&username_val).await {
                    Ok(resp) => {
                        let mut list: Vec<_> = resp.services.into_iter().collect();
                        list.sort_by(|a, b| a.0.cmp(&b.0));
                        let _ = LocalStorage::set(STORAGE_KEY, &list);
                        services.set(list);
                        error.set(None);
                    }
                    Err(e) => {
                        error.set(Some(format!("Failed to load services: {}", e)));
                    }
                }
                loading.set(false);
            });
        })
    };

    let on_service_click = {
        let navigator = navigator.clone();
        move |service: String| { navigator.push(&Route::ViewCredential { service }); }
    };

    html! {
        <div class="page">
            <div class="page-header">
                <h2>{"List Services"}</h2>
                if let Some(s) = &*session {
                    <p class="page-subtitle">{ if s.is_demo { "Demo Mode" } else { "Signed In" } }{" – "}{ &s.email }</p>
                } else {
                    <p class="page-subtitle">{"Sign up or use Demo to continue"}</p>
                }
            </div>

            if session.is_none() {
                <Card>
                    <div class="form">
                        <div class="form-group">
                            <label>{"Email"}</label>
                            <StyledInput placeholder="you@example.com" value={(*email_input).clone()} on_input={on_email_input} />
                        </div>
                        <div class="form-actions">
                            <StyledButton label="Use Demo Mode" onclick={on_demo} variant={ButtonVariant::Secondary} />
                            <StyledButton label="Sign Up" onclick={on_signup} variant={ButtonVariant::Primary} />
                        </div>
                    </div>
                </Card>
            } else {
                <div class="form-section">
                    <StyledButton label="Load Services" onclick={on_load_services} loading={*loading} variant={ButtonVariant::Primary} />
                </div>
            }

            <Toast message={(*error).clone()} variant={ToastVariant::Error} />

            if !services.is_empty() {
                <div class="services-grid">
                    { for services.iter().map(|(service, info)| {
                        let service_name = service.clone();
                        let on_click = {
                            let service_name = service_name.clone();
                            let on_service_click = on_service_click.clone();
                            Callback::from(move |_| on_service_click(service_name.clone()))
                        };
                        html! {
                            <Card clickable={true} onclick={Some(on_click)}>
                                <div class="service-card" style="display:flex;gap:12px;align-items:center;">
                                    <ServiceIcon service={service.clone()} />
                                    <div style="flex:1;">
                                        <h3 class="service-name">{ service }</h3>
                                        if let Some(username) = &info.username {
                                            <p class="service-username">{ username }</p>
                                        }
                                        if let Some(category) = &info.category {
                                            <span class="category-badge">{ category }</span>
                                        }
                                        if !info.tags.is_empty() {
                                            <div class="tags">
                                                { for info.tags.iter().map(|tag| {
                                                    let tag_class = match tag.as_str() {
                                                        "work" => "tag tag-work",
                                                        "personal" => "tag tag-personal",
                                                        "critical" => "tag tag-critical",
                                                        "financial" => "tag tag-financial",
                                                        _ => "tag tag-default",
                                                    };
                                                    html! { <span class={tag_class}>{ tag }</span> }
                                                }) }
                                            </div>
                                        }
                                    </div>
                                    <div class="service-arrow">{"→"}</div>
                                </div>
                            </Card>
                        }
                    }) }
                </div>
            }

            <div class="nav-actions">
                <StyledButton label="Add New Credential" onclick={Callback::from(move |_| navigator.push(&Route::AddCredential))} variant={ButtonVariant::Secondary} />
            </div>
        </div>
    }
}
