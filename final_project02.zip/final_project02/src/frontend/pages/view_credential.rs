use crate::backend::api;
use crate::backend::auth::load_session;
use crate::backend::models::OneCredResp;
use crate::frontend::components::*;
use crate::frontend::pages::list_services::Route;
use gloo::timers::future::TimeoutFuture;
use wasm_bindgen_futures::spawn_local;
use web_sys::window;
use yew::prelude::*;
use yew_router::prelude::*;

#[derive(Properties, PartialEq)]
pub struct Props {
    pub service: String,
}

#[function_component(ViewCredential)]
pub fn view_credential(props: &Props) -> Html {
    let credential = use_state(|| None);
    let loading = use_state(|| true);
    let error = use_state(|| None::<String>);
    let show_password = use_state(|| false);
    let copied_field = use_state(|| None::<String>);
    let navigator = use_navigator().unwrap();

    // Determine username from session; service comes from route
    let service = props.service.clone();
    let (username, is_demo) = load_session()
        .map(|s| (s.email, s.is_demo))
        .unwrap_or_else(|| (String::new(), false));

    // Load credential on mount
    {
        let credential = credential.clone();
        let loading = loading.clone();
        let error = error.clone();
        let username = username.clone();
        let service = service.clone();
        let is_demo_mode = is_demo;

        use_effect_with((), move |_| {
            spawn_local(async move {
                if is_demo_mode {
                    // Return rich mock credential for demo
                    let (
                        two_fa,
                        two_fa_method,
                        phone,
                        email,
                        backup_email,
                        tags,
                        category,
                        notes,
                        last_used,
                        created_at,
                    ) = match service.as_str() {
                        "github" => (
                            true,
                            Some("Authenticator App".to_string()),
                            Some("+1 (555) 123-4567".to_string()),
                            Some("demo@example.com".to_string()),
                            Some("demo.backup@example.com".to_string()),
                            vec!["work".to_string(), "dev".to_string()],
                            Some("Development".to_string()),
                            Some("Primary development account".to_string()),
                            Some("2 days ago".to_string()),
                            Some("2024-01-15".to_string()),
                        ),
                        "gmail" => (
                            true,
                            Some("SMS + Backup Codes".to_string()),
                            Some("+1 (555) 123-4567".to_string()),
                            Some("demo@example.com".to_string()),
                            Some("demo.recovery@proton.me".to_string()),
                            vec!["personal".to_string(), "email".to_string()],
                            Some("Email".to_string()),
                            Some("Personal email for all services".to_string()),
                            Some("1 hour ago".to_string()),
                            Some("2023-11-20".to_string()),
                        ),
                        "aws" => (
                            true,
                            Some("Hardware Security Key".to_string()),
                            Some("+1 (555) 999-8888".to_string()),
                            Some("demo@business.com".to_string()),
                            Some("aws-backup@company.com".to_string()),
                            vec!["work".to_string(), "cloud".to_string(), "critical".to_string()],
                            Some("Infrastructure".to_string()),
                            Some("Production AWS account - handle with care".to_string()),
                            Some("5 hours ago".to_string()),
                            Some("2024-02-01".to_string()),
                        ),
                        "linkedin" => (
                            true,
                            Some("Email Code".to_string()),
                            Some("+1 (555) 123-4567".to_string()),
                            Some("demo@example.com".to_string()),
                            None,
                            vec!["professional".to_string(), "social".to_string()],
                            Some("Social Media".to_string()),
                            Some("Professional networking".to_string()),
                            Some("1 week ago".to_string()),
                            Some("2023-08-10".to_string()),
                        ),
                        "slack" => (
                            true,
                            Some("SMS".to_string()),
                            Some("+1 (555) 123-4567".to_string()),
                            Some("demo@example.com".to_string()),
                            None,
                            vec!["work".to_string(), "communication".to_string()],
                            Some("Communication".to_string()),
                            Some("Team communication workspace".to_string()),
                            Some("30 mins ago".to_string()),
                            Some("2024-01-05".to_string()),
                        ),
                        "digitalocean" => (
                            true,
                            Some("Authenticator App".to_string()),
                            Some("+1 (555) 777-9999".to_string()),
                            Some("demo@business.com".to_string()),
                            Some("tech-backup@company.com".to_string()),
                            vec!["work".to_string(), "cloud".to_string(), "servers".to_string()],
                            Some("Infrastructure".to_string()),
                            Some("Droplet hosting for projects".to_string()),
                            Some("3 days ago".to_string()),
                            Some("2024-03-12".to_string()),
                        ),
                        "stripe" => (
                            true,
                            Some("Authenticator App + SMS".to_string()),
                            Some("+1 (555) 888-7777".to_string()),
                            Some("demo@business.com".to_string()),
                            Some("finance@company.com".to_string()),
                            vec!["financial".to_string(), "business".to_string()],
                            Some("Finance".to_string()),
                            Some("Payment processing for business".to_string()),
                            Some("1 day ago".to_string()),
                            Some("2024-02-20".to_string()),
                        ),
                        "notion" => (
                            false,
                            None,
                            None,
                            Some("demo@example.com".to_string()),
                            None,
                            vec!["productivity".to_string(), "notes".to_string()],
                            Some("Productivity".to_string()),
                            Some("Knowledge base and project management".to_string()),
                            Some("2 hours ago".to_string()),
                            Some("2023-12-01".to_string()),
                        ),
                        _ => (
                            false,
                            None,
                            None,
                            None,
                            None,
                            vec![],
                            None,
                            None,
                            None,
                            None,
                        ),
                    };

                    credential.set(Some(OneCredResp {
                        username: username.clone(),
                        service: service.clone(),
                        password: "SecurePass123!".to_string(),
                        two_fa_enabled: two_fa,
                        two_fa_method,
                        phone_number: phone,
                        email,
                        backup_email,
                        tags,
                        category,
                        notes,
                        last_used,
                        created_at,
                    }));
                    loading.set(false);
                    return;
                }

                match api::get_credential(&username, &service).await {
                    Ok(cred) => {
                        credential.set(Some(cred));
                        error.set(None);
                    }
                    Err(e) => {
                        error.set(Some(format!("Failed to load credential: {}", e)));
                    }
                }
                loading.set(false);
            });
            || ()
        });
    }

    let toggle_password = {
        let show_password = show_password.clone();
        Callback::from(move |_| {
            show_password.set(!*show_password);
        })
    };

    let copy_to_clipboard = {
        let copied_field = copied_field.clone();
        move |text: String, field_name: String| {
            let copied_field = copied_field.clone();
            if let Some(window) = window() {
                let clipboard = window.navigator().clipboard();
                let _ = clipboard.write_text(&text);
                copied_field.set(Some(field_name.clone()));

                spawn_local(async move {
                    TimeoutFuture::new(2_000).await;
                    copied_field.set(None);
                });
            }
        }
    };

    let on_back = {
        Callback::from(move |_| {
            navigator.push(&Route::List);
        })
    };

    html! {
        <div class="page">
            <div class="page-header">
                <h2>{"Credential Details"}</h2>
            </div>

            if *loading { <LoadingSpinner /> }
            else if let Some(cred) = (*credential).clone() {
                <div class="credential-view">
                    <Card>
                        <div class="credential-field">
                            <label>{"Service"}</label>
                            <div class="field-value">{ &cred.service }</div>
                        </div>

                        if let Some(category) = &cred.category {
                            <div class="credential-field">
                                <label>{"Category"}</label>
                                <span class="category-badge">{ category }</span>
                            </div>
                        }

                        if !cred.tags.is_empty() {
                            <div class="credential-field">
                                <label>{"Tags"}</label>
                                <div class="tags">
                                    { for cred.tags.iter().map(|tag| {
                                        let tag_class = match tag.as_str() {
                                            "work" => "tag tag-work",
                                            "personal" => "tag tag-personal",
                                            "critical" => "tag tag-critical",
                                            "financial" => "tag tag-financial",
                                            _ => "tag tag-default",
                                        };
                                        html! { <span class={tag_class}>{ tag }</span> }
                                    }) }
                                </div>
                            </div>
                        }

                        <div class="credential-field">
                            <label>{"Username"}</label>
                            <div class="field-row">
                                <div class="field-value">{ &cred.username }</div>
                                <StyledButton
                                    label={if (*copied_field).as_ref() == Some(&"username".to_string()) { "✓ Copied" } else { "Copy" }}
                                    onclick={{
                                        let text = cred.username.clone();
                                        let copy_fn = copy_to_clipboard.clone();
                                        Callback::from(move |_| copy_fn(text.clone(), "username".to_string()))
                                    }}
                                    variant={ButtonVariant::Secondary}
                                />
                            </div>
                        </div>

                        <div class="credential-field">
                            <label>{"Password"}</label>
                            <div class="field-row">
                                <div class="field-value password-field">
                                    if *show_password { { &cred.password } } else { { "••••••••••••" } }
                                </div>
                                <StyledButton
                                    label={if *show_password { "Hide" } else { "Show" }}
                                    onclick={toggle_password}
                                    variant={ButtonVariant::Secondary}
                                />
                                <StyledButton
                                    label={if (*copied_field).as_ref() == Some(&"password".to_string()) { "✓ Copied" } else { "Copy" }}
                                    onclick={{
                                        let text = cred.password.clone();
                                        let copy_fn = copy_to_clipboard.clone();
                                        Callback::from(move |_| copy_fn(text.clone(), "password".to_string()))
                                    }}
                                    variant={ButtonVariant::Primary}
                                />
                            </div>
                        </div>

                        <div class="credential-field security-info">
                            <label>{"Two-Factor Authentication"}</label>
                            <div class="field-value">
                                if cred.two_fa_enabled {
                                    <span class="badge badge-success">{"✓ Enabled"}</span>
                                    if let Some(method) = &cred.two_fa_method {
                                        <span class="text-muted">{format!(" ({})", method)}</span>
                                    }
                                } else {
                                    <span class="badge badge-warning">{"✗ Disabled"}</span>
                                }
                            </div>
                        </div>

                        if let Some(phone) = &cred.phone_number {
                            <div class="credential-field">
                                <label>{"Phone Number"}</label>
                                <div class="field-row">
                                    <div class="field-value">{ phone }</div>
                                    <StyledButton
                                        label={if (*copied_field).as_ref() == Some(&"phone".to_string()) { "✓ Copied" } else { "Copy" }}
                                        onclick={{
                                            let text = phone.clone();
                                            let copy_fn = copy_to_clipboard.clone();
                                            Callback::from(move |_| copy_fn(text.clone(), "phone".to_string()))
                                        }}
                                        variant={ButtonVariant::Secondary}
                                    />
                                </div>
                            </div>
                        }

                        if let Some(email) = &cred.email {
                            <div class="credential-field">
                                <label>{"Email"}</label>
                                <div class="field-row">
                                    <div class="field-value">{ email }</div>
                                    <StyledButton
                                        label={if (*copied_field).as_ref() == Some(&"email".to_string()) { "✓ Copied" } else { "Copy" }}
                                        onclick={{
                                            let text = email.clone();
                                            let copy_fn = copy_to_clipboard.clone();
                                            Callback::from(move |_| copy_fn(text.clone(), "email".to_string()))
                                        }}
                                        variant={ButtonVariant::Secondary}
                                    />
                                </div>
                            </div>
                        }

                        if let Some(backup_email) = &cred.backup_email {
                            <div class="credential-field">
                                <label>{"Backup Email"}</label>
                                <div class="field-row">
                                    <div class="field-value">{ backup_email }</div>
                                    <StyledButton
                                        label={if (*copied_field).as_ref() == Some(&"backup_email".to_string()) { "✓ Copied" } else { "Copy" }}
                                        onclick={{
                                            let text = backup_email.clone();
                                            let copy_fn = copy_to_clipboard.clone();
                                            Callback::from(move |_| copy_fn(text.clone(), "backup_email".to_string()))
                                        }}
                                        variant={ButtonVariant::Secondary}
                                    />
                                </div>
                            </div>
                        }

                        if cred.notes.is_some() || cred.last_used.is_some() || cred.created_at.is_some() {
                            <div class="metadata">
                                if let Some(notes) = &cred.notes {
                                    <div class="metadata-item">
                                        <span class="metadata-label">{"Notes:"}</span>
                                        <span class="metadata-value">{ notes }</span>
                                    </div>
                                }
                                if let Some(last_used) = &cred.last_used {
                                    <div class="metadata-item">
                                        <span class="metadata-label">{"Last Used:"}</span>
                                        <span class="metadata-value">{ last_used }</span>
                                    </div>
                                }
                                if let Some(created) = &cred.created_at {
                                    <div class="metadata-item">
                                        <span class="metadata-label">{"Created:"}</span>
                                        <span class="metadata-value">{ created }</span>
                                    </div>
                                }
                            </div>
                        }
                    </Card>
                </div>
            }

            <Toast message={(*error).clone()} variant={ToastVariant::Error} />

            <div class="nav-actions">
                <StyledButton label="← Back to List" onclick={on_back} variant={ButtonVariant::Secondary} />
            </div>
        </div>
    }
}
