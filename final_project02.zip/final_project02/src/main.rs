mod app;
mod frontend;
mod backend;

fn main() {
    yew::Renderer::<app::App>::new().render();
}
